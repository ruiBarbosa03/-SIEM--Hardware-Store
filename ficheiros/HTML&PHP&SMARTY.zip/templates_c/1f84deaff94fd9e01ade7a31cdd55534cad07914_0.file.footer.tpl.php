<?php
/* Smarty version 3.1.30, created on 2016-11-28 12:35:14
  from "/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_583c2482e83d23_59690771',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f84deaff94fd9e01ade7a31cdd55534cad07914' => 
    array (
      0 => '/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/footer.tpl',
      1 => 1479731146,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_583c2482e83d23_59690771 (Smarty_Internal_Template $_smarty_tpl) {
?>
		<div class="footer">
					<hr class="style-one">
					<p>Francisco Ferreira ee12195</p>
					<p>Rui Barbosa ee12014</p>
		</div>
	</body>

</html><?php }
}
