<?php
	include_once ('../../config/init.php');
	
	$smarty->display('public/sobreNos.tpl');
?>