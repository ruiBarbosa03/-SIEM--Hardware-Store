<?php
/* Smarty version 3.1.30, created on 2016-12-25 18:49:27
  from "/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/header_initial.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586014b76172f2_44992361',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '496676733576e8765fd167a66ff28460f27e88aa' => 
    array (
      0 => '/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/header_initial.tpl',
      1 => 1481813694,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_586014b76172f2_44992361 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>

	<head>
		<title> Loja do Canto </title>
		
		<link rel="icon" 	 href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
images/Logo_empresa.png"  type="image\gif"/>  
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel=StyleSheet type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/initial.css"/>
		<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.12.4.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/main.js"><?php echo '</script'; ?>
>
		<meta charset="UTF-8">
		
	</head>

	<body>
		<?php }
}
