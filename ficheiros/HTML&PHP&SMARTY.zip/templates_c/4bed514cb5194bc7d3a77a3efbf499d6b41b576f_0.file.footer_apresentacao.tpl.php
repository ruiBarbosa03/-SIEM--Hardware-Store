<?php
/* Smarty version 3.1.30, created on 2016-11-28 12:35:10
  from "/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/footer_apresentacao.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_583c247ede84e8_03669010',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4bed514cb5194bc7d3a77a3efbf499d6b41b576f' => 
    array (
      0 => '/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/footer_apresentacao.tpl',
      1 => 1479731146,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_583c247ede84e8_03669010 (Smarty_Internal_Template $_smarty_tpl) {
?>
	</body>

</html><?php }
}
