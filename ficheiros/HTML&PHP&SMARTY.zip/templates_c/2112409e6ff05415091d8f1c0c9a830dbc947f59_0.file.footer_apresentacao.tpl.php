<?php
/* Smarty version 3.1.30, created on 2016-11-20 14:44:03
  from "/usr/users2/mieec2012/ee12195/public_html/SIEMTrabalho3/templates/common/footer_apresentacao.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5831b6b34c9ac3_10382763',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2112409e6ff05415091d8f1c0c9a830dbc947f59' => 
    array (
      0 => '/usr/users2/mieec2012/ee12195/public_html/SIEMTrabalho3/templates/common/footer_apresentacao.tpl',
      1 => 1479652418,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5831b6b34c9ac3_10382763 (Smarty_Internal_Template $_smarty_tpl) {
?>
	</body>

</html><?php }
}
