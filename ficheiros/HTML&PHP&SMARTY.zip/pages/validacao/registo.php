<?php
	include_once ('../../config/init.php');
	
	$smarty->display('validacao/registo.tpl');
?>