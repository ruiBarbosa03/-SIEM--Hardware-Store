<?php
/* Smarty version 3.1.30, created on 2016-12-25 18:47:36
  from "/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/header_apresentacao.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58601448f354c9_12007315',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '185513794ebd19c7503fd22e8264039ee03ac3dd' => 
    array (
      0 => '/usr/users2/mieec2012/ee12014/public_html/SIEMTrabalho3/templates/common/header_apresentacao.tpl',
      1 => 1481813698,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58601448f354c9_12007315 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<title> Loja do Canto </title>
			
		<link rel="icon" 	 href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
images/Logo_empresa.png"  type="image\gif"/>  
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel=StyleSheet type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/apresentacao.css"/>
		<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.12.4.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/main.js"><?php echo '</script'; ?>
>	
		<meta charset="UTF-8">	
	</head>

	<body><?php }
}
