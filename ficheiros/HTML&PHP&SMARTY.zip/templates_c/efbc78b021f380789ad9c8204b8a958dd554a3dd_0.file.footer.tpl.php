<?php
/* Smarty version 3.1.30, created on 2017-01-08 16:06:07
  from "/usr/users2/mieec2012/ee12195/public_html/SIEMTrabalho3/templates/common/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5872636f182635_86203446',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'efbc78b021f380789ad9c8204b8a958dd554a3dd' => 
    array (
      0 => '/usr/users2/mieec2012/ee12195/public_html/SIEMTrabalho3/templates/common/footer.tpl',
      1 => 1483891485,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5872636f182635_86203446 (Smarty_Internal_Template $_smarty_tpl) {
?>
		<div class="footer">
					<hr class="style-one">
					<p>Francisco Ferreira ee12195</p>
					<p>Rui Barbosa ee12014</p>
		</div>
		
	</body>

</html><?php }
}
